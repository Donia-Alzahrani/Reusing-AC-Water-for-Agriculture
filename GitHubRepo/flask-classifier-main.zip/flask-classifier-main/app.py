from flask import Flask, request, jsonify
from flask_cors import CORS
import firebase_admin
from firebase_admin import credentials, db
import pandas as pd
import joblib
import os
import smtplib
from email.mime.text import MIMEText
from datetime import datetime
from dotenv import load_dotenv
from datetime import datetime, timedelta


# --- Setup Flask ---
app = Flask(__name__)
CORS(app)
load_dotenv()

last_email_time = None


# --- Initialize notification settings ---
notification_settings = {
    "email": None,
    "enabled": True,
    "no_notify": {},
    "cooldown_minutes": 10,  # default
}

@app.route("/update-settings", methods=["POST"])
def update_settings():
    data = request.get_json()
    notification_settings["email"] = data.get("email")
    notification_settings["enabled"] = data.get("enabled")
    notification_settings["no_notify"] = data.get("no_notify", {})
    notification_settings["cooldown_minutes"] = data.get("cooldown_minutes", 10)
    return jsonify({"status": "success"}), 200


def send_email_if_allowed(subject, message):
    global last_email_time
    cooldown_minutes = notification_settings.get("cooldown_minutes", 10)  # fallback to 10
    EMAIL_COOLDOWN = timedelta(minutes=cooldown_minutes)
    if not notification_settings.get("enabled", False):
        return "Notifications disabled."

    now = datetime.now()

    # Check cooldown
    if last_email_time and now - last_email_time < EMAIL_COOLDOWN:
        return f"Notification skipped: Cooldown active. Last sent at {last_email_time.strftime('%H:%M:%S')}"

    # Time-based and day-based checks (same as before)
    current_time = now.strftime("%H:%M")
    current_day = now.strftime("%A").lower()
    no_notify = notification_settings.get("no_notify", {})
    blocked_start = no_notify.get("start", "00:00")
    blocked_end = no_notify.get("end", "00:00")
    blocked_day = no_notify.get("days", {}).get(current_day, False)

    def is_time_blocked(start, end, now):
        return (start <= now <= end) if start < end else (now >= start or now <= end)

    if blocked_day and is_time_blocked(blocked_start, blocked_end, current_time):
        return f"Notification skipped: {blocked_start} to {blocked_end} on {current_day}"

    # Attempt to send email
    try:
        smtp_server = "smtp.gmail.com"
        smtp_port = 587
        sender_email = os.getenv("EMAIL_USER")
        sender_password = os.getenv("EMAIL_APP_PASSWORD")
        receiver_email = notification_settings["email"]

        msg = MIMEText(message)
        msg["Subject"] = subject
        msg["From"] = sender_email
        msg["To"] = receiver_email

        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver_email, msg.as_string())

        last_email_time = now  # Update cooldown
        return "Email sent."

    except Exception as e:
        return f"Failed to send email: {str(e)}"
        
# --- Firebase Setup ---
cred = credentials.Certificate("firebase-service-account.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://aquaguard-tkmj6-default-rtdb.firebaseio.com/'
})

# --- Load model ---
model = joblib.load('svm_model.pkl')
scaler = joblib.load('scaler.pkl')

@app.route("/", methods=["GET"])
def health_check():
    return "Flask server is running!", 200

@app.route("/classify", methods=["POST"])
def classify():
    try:
        data = request.get_json()
        reading = data.get("reading")
        if not reading:
            return jsonify({"error": "Missing 'reading' field"}), 400

        required_keys = ['temp_sensor', 'tds_sensor', 'ph_sensor', 'turbidity_sensor']
        if not all(key in reading for key in required_keys):
            return jsonify({"error": "Missing sensor values"}), 400

        df = pd.DataFrame([[float(reading['temp_sensor']),
                            float(reading['tds_sensor']),
                            float(reading['ph_sensor']),
                            float(reading['turbidity_sensor'])]],
                          columns=required_keys)

        scaled = scaler.transform(df)
        prediction = int(model.predict(scaled)[0])

        if prediction == 0:
            result = send_email_if_allowed(
                subject="⚠️ AquaSprout Alert: Water Unsuitable",
                message="Warning: Water quality is currently unsafe. Please check your system."
            )
            print(result)


        data["classification"] = prediction
        data["time"] = {".sv": "timestamp"}

        ref = db.reference("/sensor_data_classified")
        ref.push(data)

        return jsonify({"status": "success", "classification": prediction}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500
        
@app.route("/get-settings", methods=["GET"])
def get_settings():
    return jsonify(notification_settings), 200

if __name__ == "__main__":
    app.run(debug=True)
